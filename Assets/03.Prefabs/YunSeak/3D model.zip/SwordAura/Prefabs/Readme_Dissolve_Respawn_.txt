Please note that when exporting the following two Effects;

- Dissolve
- Respawn

both automatically include several unnecessary dependencies when exporting as a package. Please ensure that only files within the "EffectExamples" folder are ticked. As long as the "Materials", "Prefabs", "Scripts", "Shaders" and "Textures" folders are ticked, the effect will work correctly once imported in a new project.